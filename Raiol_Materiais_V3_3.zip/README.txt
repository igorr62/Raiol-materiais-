Raiol Materiais V3.3

Novidades: histórico por mês, fechamento mensal sem apagar vendas, dinheiro a receber para vendas fiadas, cliente/vencimento, recebimentos parciais e integração com o caixa.

Use o index.html para substituir o publicado no GitHub Pages. A chave de armazenamento permanece raiol_materiais_v3 para preservar os dados da V3.2.
